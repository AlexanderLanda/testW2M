package com.example.TestTecnico.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.TestTecnico.Model.Heroe;
import com.example.TestTecnico.Repository.HeroeRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

@Component
public class HeroeService {

	@Autowired
	private HeroeRepository heroeRepository;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public Heroe createHeroe(Heroe heroe) {
		return heroeRepository.save(heroe);
	}
	
	public Optional<Heroe> getHeroeByID(Long id) {
		Optional<Heroe> optionalHeroe = heroeRepository.findById(id);
		return optionalHeroe;
	}
	
	public List<Heroe> getHeroes(){
		return heroeRepository.findAll();
	}
	
	public void deleteHeroe(Long id) {
		heroeRepository.deleteById(id);
		
	}
	
	public List<Heroe> getHeroeContains(String line){
		Query query = entityManager.createQuery("SELECT e FROM Heroe e WHERE e.name LIKE :valor");
        query.setParameter("valor", "%" + line + "%"); 
        return query.getResultList();
	}
	
	public void modificarHeroe(Long id, String nameNew) {
		Optional<Heroe> h = heroeRepository.findById(id);
		h.get().setName(nameNew);
		heroeRepository.save(h.get());
	}
}
