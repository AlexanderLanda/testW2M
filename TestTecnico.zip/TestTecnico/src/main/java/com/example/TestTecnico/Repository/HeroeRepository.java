package com.example.TestTecnico.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.TestTecnico.Model.Heroe;

@Repository
public interface HeroeRepository extends JpaRepository<Heroe, Long>{

}
