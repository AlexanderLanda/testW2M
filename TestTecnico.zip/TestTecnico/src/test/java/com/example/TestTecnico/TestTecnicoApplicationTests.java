package com.example.TestTecnico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTecnicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
