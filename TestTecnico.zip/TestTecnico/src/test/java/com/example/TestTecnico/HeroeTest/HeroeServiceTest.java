package com.example.TestTecnico.HeroeTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.example.TestTecnico.Model.Heroe;
import com.example.TestTecnico.Repository.HeroeRepository;
import com.example.TestTecnico.Service.HeroeService;

public class HeroeServiceTest {

    @Mock
    private HeroeRepository heroeRepository;

    @InjectMocks
    private HeroeService heroeService;

    @Test
    public void testObtenerHeroePorId() {
        Long id = 1L;
        String nombreHeroe = "Alexander Landa";
        Heroe heroe = new Heroe(nombreHeroe);

        when(heroeRepository.findById(id)).thenReturn(Optional.of(heroe));

        Optional<Heroe> resultado = heroeService.getHeroeByID(id);

        assertEquals(nombreHeroe, resultado.get().getName());
    }
    
    @Test
    public void testCrearHeroe() {
        Heroe heroe = new Heroe("Wonder Woman");

        when(heroeRepository.save(heroe)).thenReturn(heroe);
        Heroe resultado = heroeService.createHeroe(heroe);
        assertEquals(heroe.getName(), resultado.getName());
    }

    @Test
    public void testActualizarHeroe() {
        Long id = 1L;
        Heroe heroeExistente = new Heroe("Aquaman");
        Heroe nuevoHeroe = new Heroe("Flash");

        heroeService.modificarHeroe(id, nuevoHeroe.getName());

        verify(heroeRepository, times(1)).save(nuevoHeroe);
    }

    @Test
    public void testEliminarHeroe() {
        Long id = 1L;
        heroeService.deleteHeroe(id);

        verify(heroeRepository, times(1)).deleteById(id);
    }

    @Test
    public void testEliminarHeroeNoExistente() {
        Long id = 999L;

        doThrow(new IllegalArgumentException()).when(heroeRepository).deleteById(id);

        assertThrows(IllegalArgumentException.class, () -> heroeService.deleteHeroe(id));
    }
}
